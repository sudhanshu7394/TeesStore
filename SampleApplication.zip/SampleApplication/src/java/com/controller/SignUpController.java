/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.bean.SignUpBean;
import com.model.LoginModel;
import com.model.SignUpModel;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author pruthvirajsinh
 */
public class SignUpController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    
        SignUpBean sb = new SignUpBean();
        sb.setFname(req.getParameter("fname"));
        sb.setUid(req.getParameter("uid"));
        sb.setEmail(req.getParameter("email"));
        sb.setPass(req.getParameter("pass"));
        sb.setAdd(req.getParameter("add"));
        sb.setPhone(req.getParameter("phone"));
        sb.setCity(req.getParameter("city"));       
        
        SignUpModel signupmodel = new SignUpModel();
        signupmodel.addUser(sb);
        
        resp.setContentType("text/html");
        SignUpBean sib = new SignUpBean();
        
        String uname = req.getParameter("uid");
        sib.setUid(req.getParameter("uid"));
        sib.setPass(req.getParameter("pass"));
        
        SignUpModel sm = new SignUpModel();
        boolean flag = sm.checkLogin(sib);
        if(flag==true){
            HttpSession session = req.getSession(true);
            String uid = (req.getParameter("uid"));
            LoginModel lm = new LoginModel();
            SignUpBean sub = lm.searchUser(uid);
            session.setAttribute("uid", sub);
            session.setAttribute("abc", uname);
            Cookie ck = new Cookie("abc", uname);
            ck.setMaxAge(60*60);
            resp.sendRedirect("index1.jsp");
        } else {
            PrintWriter out = resp.getWriter();
            out.println("User name incorresct");
        }
        
    }
    int[] array = {10,20};
    int a = array.length;
    
}
