/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.bean.SignUpBean;
import com.connection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author pruthvirajsinh
 */
public class SignUpModel {

    public void addUser(SignUpBean sb) {
        try {

            DbConnection db = new DbConnection();
            Connection conn = db.getConnection();
            String sql = "INSERT INTO signup (`fname`,`uid`,`email`,`pass`,`add`,`phone`,`city`) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, sb.getFname());
            stm.setString(2, sb.getUid());
            stm.setString(3, sb.getEmail());
            stm.setString(4, sb.getPass());
            stm.setString(5, sb.getAdd());
            stm.setString(6, sb.getPhone());
            stm.setString(7, sb.getCity());

            int i = stm.executeUpdate();
            if (i > 0) {
                System.out.println("Data added Successfully");
            } else {
                System.out.println("Error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean checkLogin(SignUpBean sb) {

        boolean flag = false;
        try {
            DbConnection db = new DbConnection();
            Connection conn = db.getConnection();
            String sql = "SELECT * FROM signup WHERE `uid`=? and `pass`=?";
            PreparedStatement pr = conn.prepareStatement(sql);
            pr.setString(1, sb.getUid());
            pr.setString(2, sb.getPass());
            ResultSet rs = pr.executeQuery();
            if (rs.next()) {
                flag = true;
            } else {
                flag = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
