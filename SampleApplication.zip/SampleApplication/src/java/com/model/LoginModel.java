/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.bean.SignUpBean;
import com.connection.DbConnection;
import com.sun.xml.ws.tx.at.v10.types.PrepareResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author pruthvirajsinh
 */
public class LoginModel {

    public SignUpBean searchUser(String uid) {
        SignUpBean sb = new SignUpBean();
        try {
            DbConnection db = new DbConnection();
            Connection conn = db.getConnection();
            String sql = "SELECT * FROM signup WHERE uid=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, uid);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                sb.setFname(rs.getString("fname"));
                sb.setUid(rs.getString("uid"));
                sb.setEmail(rs.getString("email"));
                sb.setPass(rs.getString("pass"));
                sb.setAdd(rs.getString("add"));
                sb.setPhone(rs.getString("phone"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb;
    }
}
